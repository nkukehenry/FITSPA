
        <center style="padding:20px;">
               
           <img style="border-radius:12px" src="<?php echo base_url(); ?>public/images/fitspan-xmas.jfif"/>
           </center> 
